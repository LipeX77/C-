﻿namespace WinFormsApp2
{
    public partial class MenuInicial : Form
    {
        /* 
         ==========================================================================================
         Contribuições e mudanças que implementei neste jogo (minha versão)
         ------------------------------------------------------------------------------------------
         • Três modos de dificuldade:
           - Fácil (NivelFacil): palavras embaralhadas; botão de dica mostra a primeira e última letra.
           - Médio (NivelMedio): 10 palavras fixas; botão de dica mostra apenas a primeira letra.
           - Difícil (NivelDificil): 15 palavras fixas; sem dicas.

         • Progressão e HUD:
           - lblWord: exibe a palavra embaralhada (ou mensagem de vitória).
           - lblInfo: mostra "Palavra X de Y".
           - lblGuessed: contador de erros.

         • Fluxo do jogo:
           - Jogador digita no TextBox e pressiona Enter.
           - Se acertar → avança para a próxima palavra.
           - Se errar → incrementa contador de erros.
           - Ao completar todas as palavras → mensagem de vitória.

         • Organização do projeto:
           - MenuInicial → acessa MenuDificuldades.
           - MenuDificuldades → acessa os níveis (Fácil, Médio, Difícil).
           - Cada nível implementa suas regras próprias.
         ========================================================================================== 
        */

        public MenuInicial()
        {
            // Inicializa todos os componentes visuais definidos no Designer
            InitializeComponent();
        }

        // ----------------- BOTÃO "JOGAR" -----------------
        private void button1_Click(object sender, EventArgs e)
        {
            // Cria a janela de seleção de dificuldades e passa a instância atual (MenuInicial)
            MenuDificuldades niveis_dificuldade = new MenuDificuldades(this);
            
            // Mostra a nova janela
            niveis_dificuldade.Show();
            
            // Esconde a tela inicial (não fecha, apenas oculta)
            this.Hide();
        }

        // ----------------- BOTÃO "REGRAS" -----------------
        private void button2_Click(object sender, EventArgs e)
        {
            // Texto explicativo das regras do jogo
            string regras = "Regras do Jogo - Guess The Word\n\n" +
                            "1. Descubra a palavra embaralhada e digite no campo.\n" +
                            "2. Pressione Enter para confirmar sua resposta.\n" +
                            "3. Cada erro aumenta o contador de erros.\n" +
                            "4. Níveis:\n" +
                            "   - Fácil: dica da primeira e última letra.\n" +
                            "   - Médio: dica apenas da primeira letra.\n" +
                            "   - Difícil: sem dicas.\n" +
                            "5. Acertar todas as palavras vence o nível.\n\n" +
                            "Boa sorte!";
            
            // Exibe as regras em uma MessageBox
            MessageBox.Show(regras, "Regras do Jogo");
        }

        public static implicit operator MenuInicial(NivelDificil v)
        {
            // Lançado se alguém tentar converter um NivelDificil em MenuInicial (não implementado)
            throw new NotImplementedException();
        }
    }
}

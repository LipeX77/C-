﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace WinFormsApp2
{
    public partial class NivelFacil : Form
    {
        // Lista de palavras usadas no nível fácil
        // Obs: são palavras simples e curtas
        List<string> words = new List<string>()
        {
            "terra", "cachorro", "flor", "peixe", "gato",
            "cadeira", "copo", "árvore", "fogo", "chuva"
        };

        // Guarda a versão embaralhada da palavra atual
        string scrambledWord;

        // Índice da palavra atual na lista
        int currentIndex = 0;

        // Contador de erros cometidos pelo jogador
        int guessed = 0;

        public NivelFacil()
        {
            InitializeComponent();

            // Quando o form abre, carrega a primeira palavra
            SetupWord();
        }

        /// 
        /// Configura a palavra da vez:
        /// - Embaralha a palavra
        /// - Atualiza os labels (palavra, progresso e erros)
        /// 
        private void SetupWord()
        {
            scrambledWord = ScrambleWord(words[currentIndex]);
            lblWord.Text = scrambledWord;
            lblInfo.Text = $"Palavra {currentIndex + 1} de {words.Count}";
            lblGuessed.Text = $"Erros: {guessed}";
        }

        /// Função que embaralha as letras da palavra
        private string ScrambleWord(string word)
        {
            if (word.Length <= 1) return word;

            var letters = word.ToCharArray();
            var random = new Random();

            // Reordena as letras de forma aleatória
            letters = letters.OrderBy(x => random.Next()).ToArray();

            return new string(letters);
        }

        /// Evento de tecla pressionada
        /// - Quando o jogador pressiona ENTER, verifica a resposta
        private void KeyIsPressed(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                string answer = textBox1.Text.Trim();

                // Se a resposta estiver correta
                if (answer.Equals(words[currentIndex], StringComparison.OrdinalIgnoreCase))
                {
                    // Se ainda houver palavras, avança
                    if (currentIndex < words.Count - 1)
                    {
                        MessageBox.Show("Correto!", "Fácil Says:");
                        textBox1.Text = "";
                        currentIndex++;
                        guessed = 0; // reseta erros
                        SetupWord();
                    }
                    else
                    {
                        MessageBox.Show("Você venceu o nível fácil!", "Parabéns 🎉");

                        // Volta para o menu inicial
                        MenuInicial menu = new MenuInicial();
                        menu.Show();
                        this.Close(); // fecha o nível fácil
                    }
                }
                else
                {
                    // Resposta errada → soma erro
                    guessed++;
                    lblGuessed.Text = $"Erros: {guessed}";
                }

                // Impede o beep padrão do ENTER
                e.Handled = true;
            }
        }

        /// Botão de dica:
        /// - Mostra a primeira e a última letra da palavra
        private void button1_Click(object sender, EventArgs e)
        {
            string currentWord = words[currentIndex];
            char firstLetter = currentWord[0];
            char lastLetter = currentWord[currentWord.Length - 1];

            string message = $"DICA!!\nPrimeira letra: {firstLetter}!\nÚltima letra: {lastLetter}!";
            MessageBox.Show(message, "Dica");
        }
    }
}

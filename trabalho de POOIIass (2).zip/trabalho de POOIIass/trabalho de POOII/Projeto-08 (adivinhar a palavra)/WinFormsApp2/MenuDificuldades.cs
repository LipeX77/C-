﻿namespace WinFormsApp2
{
    public partial class MenuDificuldades : Form
    {
        // ----------------- REFERÊNCIAS A OUTRAS TELAS -----------------
        MenuInicial menu_inicial;    // Tela inicial (Menu)
        NivelFacil modo_facil;       // Tela do modo fácil
        NivelMedio modo_medio;       // Tela do modo médio
        NivelDificil modo_dificil;   // Tela do modo difícil

        // ----------------- CONSTRUTOR PADRÃO -----------------
        public MenuDificuldades()
        {
            InitializeComponent();
            // Inicializa componentes visuais (botões, labels, etc.)
        }

        // ----------------- CONSTRUTORES SOBRECARGADOS -----------------
        public MenuDificuldades(MenuInicial f1)
        {
            InitializeComponent();
            this.menu_inicial = f1; // Guarda referência ao MenuInicial
        }

        // ----------------- VOLTAR PARA O MENU INICIAL -----------------
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            // Cria uma nova instância do MenuInicial
            menu_inicial = new MenuInicial();

            // Exibe a tela inicial novamente
            menu_inicial.Show();

            // Esconde o menu de dificuldades
            this.Hide();
        }

        // ----------------- BOTÃO "FÁCIL" -----------------
        private void button1_Click(object sender, EventArgs e)
        {
            // Cria a tela do modo fácil
            modo_facil = new NivelFacil();

            // Exibe o jogo no modo fácil
            modo_facil.Show();

            // Esconde o menu de dificuldades
            this.Hide();
        }

        // ----------------- BOTÃO "MÉDIO" -----------------
        private void button2_Click(object sender, EventArgs e)
        {
            // Cria a tela do modo médio
            modo_medio = new NivelMedio();

            // Exibe o jogo no modo médio
            modo_medio.Show();

            // Esconde o menu de dificuldades
            this.Hide();
        }

        // ----------------- BOTÃO "DIFÍCIL" -----------------
        private void button3_Click(object sender, EventArgs e)
        {
            // Cria a tela do modo difícil
            modo_dificil = new NivelDificil();

            // Exibe o jogo no modo difícil
            modo_dificil.Show();

            // Esconde o menu de dificuldades
            this.Hide();
        }
    }
}

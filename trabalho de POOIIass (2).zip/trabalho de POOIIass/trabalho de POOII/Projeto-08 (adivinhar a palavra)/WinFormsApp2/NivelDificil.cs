﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace WinFormsApp2
{
    public partial class NivelDificil : Form
    {
        // Lista de 15 palavras mais longas/complexas para o nível difícil
        List<string> words = new List<string>()
        {
            "computador", "programacao", "microfone", "laboratorio", "matematica",
            "eletricidade", "astronomia", "geometria", "cibernetica", "linguistica",
            "fotografia", "quimica", "filatelia", "ornitologia", "hipotese"
        };

        // Palavra atual (embaralhada) exibida ao jogador
        string scrambledWord;

        // Índice da palavra atual na lista
        int currentIndex = 0;

        // Contador de erros cometidos pelo jogador
        int guessed = 0;

        public NivelDificil()
        {
            InitializeComponent();

            // Quando o form abre, configura a primeira palavra
            SetupWord();
        }

        /// 
        /// Prepara a palavra da rodada:
        /// - Embaralha
        /// - Atualiza labels com progresso e erros
        /// 
        private void SetupWord()
        {
            scrambledWord = ScrambleWord(words[currentIndex]);
            lblWord.Text = scrambledWord;
            lblInfo.Text = $"Palavra {currentIndex + 1} de {words.Count}";
            lblGuessed.Text = $"Erros: {guessed}";
        }

        /// 
        /// Função que embaralha as letras de uma palavra
        /// 
        private string ScrambleWord(string word)
        {
            var random = new Random();

            // Usa LINQ para embaralhar aleatoriamente
            return new string(word.ToCharArray().OrderBy(x => random.Next()).ToArray());
        }

        /// 
        /// Evento de tecla pressionada:
        /// - Ao pressionar ENTER, verifica a resposta
        /// 
        private void KeyIsPressed(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                string answer = textBox1.Text.Trim();

                // Se acertar
                if (answer.Equals(words[currentIndex], StringComparison.OrdinalIgnoreCase))
                {
                    MessageBox.Show("Correto!", "Modo Difícil:");
                    currentIndex++;       // passa para a próxima palavra
                    guessed = 0;          // zera erros da rodada
                    textBox1.Text = "";   // limpa a caixa de texto

                    // Se terminou todas as palavras → vitória
                    if (currentIndex >= words.Count)
                    {
                        MessageBox.Show("Você venceu o nível difícil!", "Parabéns 🎉");

                        // Volta para o menu inicial
                        MenuInicial menu = new MenuInicial();
                        menu.Show();
                        this.Close();
                        return;
                    }

                    // Caso contrário, prepara a próxima palavra
                    SetupWord();
                }
                else
                {
                    // Se errou → soma erro
                    guessed++;
                    lblGuessed.Text = $"Erros: {guessed}";
                }

                // Impede o "beep" do ENTER
                e.Handled = true;
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace WinFormsApp2
{
    public partial class NivelMedio : Form
    {
        // Lista de palavras que serão usadas no nível médio
        // Obs: a palavra é embaralhada e o jogador precisa adivinhar
        List<string> words = new List<string>()
        {
            "casa", "carro", "computador", "janela", "escola",
            "relogio", "telefone", "montanha", "livro", "chocolate"
        };

        // Variável que guarda a palavra embaralhada
        string scrambledWord;

        // Índice da palavra atual dentro da lista
        int currentIndex = 0;

        // Contador de erros cometidos na palavra atual
        int guessed = 0;

        public NivelMedio()
        {
            InitializeComponent();

            // Quando a tela abre, já carrega a primeira palavra
            SetupWord();
        }

        /// 
        /// Configura a palavra da vez:
        /// - Embaralha as letras
        /// - Mostra no label
        /// - Atualiza informações de progresso e erros
        /// 
        private void SetupWord()
        {
            scrambledWord = ScrambleWord(words[currentIndex]);
            lblWord.Text = scrambledWord;
            lblInfo.Text = $"Palavra {currentIndex + 1} de {words.Count}";
            lblGuessed.Text = $"Erros: {guessed}";
        }

        /// 
        /// Função que embaralha a palavra
        /// 
        private string ScrambleWord(string word)
        {
            var letters = word.ToCharArray();
            var random = new Random();

            // Reordena as letras aleatoriamente
            letters = letters.OrderBy(x => random.Next()).ToArray();
            return new string(letters);
        }

        /// 
        /// Evento disparado quando o jogador aperta alguma tecla
        /// - Se for ENTER, confere a resposta digitada
        /// 
        private void KeyIsPressed(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                string answer = textBox1.Text.Trim();

                // Verifica se a resposta está correta
                if (answer.Equals(words[currentIndex], StringComparison.OrdinalIgnoreCase))
                {
                    // Se ainda houver mais palavras, vai para a próxima
                    if (currentIndex < words.Count - 1)
                    {
                        MessageBox.Show("Correto!", "Médio Says:");
                        textBox1.Text = "";
                        currentIndex++;
                        guessed = 0; // reseta os erros
                        SetupWord();
                    }
                    else
                    {
                        // Se for a última palavra: vitória!
                        MessageBox.Show("Você venceu o nível médio!", "Parabéns 🎉");

                        // Volta para o menu inicial
                        MenuInicial menu = new MenuInicial();
                        menu.Show();
                        this.Close(); // fecha o nível médio
                    }
                }
                else
                {
                    // Se errou, soma erro
                    guessed++;
                    lblGuessed.Text = $"Erros: {guessed}";
                }

                // Impede o beep padrão da tecla ENTER
                e.Handled = true;
            }
        }

        /// 
        /// Botão de dica:
        /// - Mostra a primeira letra da palavra como ajuda
        /// 
        private void button1_Click(object sender, EventArgs e)
        {
            string currentWord = words[currentIndex];
            char firstLetter = currentWord[0];
            string message = $"DICA!!\nPrimeira letra: {firstLetter}!";
            MessageBox.Show(message, "Dica");
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfApp1.Model;

namespace WpfApp1.Persistencia
{
    internal class BD
    {
        public static int IndexGlobal { get; set; } = 0;

        public static List<RedeAmigo> mybd = new();

        public static void SalvarDB(RedeAmigo i)
        {
            if (i.IdRedeAmigo == 0)
            {
                i.IdRedeAmigo = ++IndexGlobal;
                mybd.Add(i);
            }
        }

        public static RedeAmigo? RetornarBD(int id)
        {

            RedeAmigo objRet = null;

            objRet = mybd.Find(ii => { return ii.IdRedeAmigo == id; });

            return objRet;
        }

        public static List<RedeAmigo> RetornarBD() => mybd;
    }
}

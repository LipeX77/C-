﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfApp1.Model;

namespace WpfApp1.Control
{
    internal class RedeAmigoControle
    {
        private RedeAmigo ModeloPersistencia = new();

        public Boolean ControleCadastrarRedeAmigo(string ap, string tel, )
        {

            ideia = ideia + "Amigo do Saski";

            RedeAmigo ii = new()
            {
                Area = area,
                Ideia = ideia,
                Custo = custo
            };

            if (ModeloPersistencia.CadastrarIdeiaInovacao(ii))
                return true;
            return false;
        }
        public List<RedeAmigo> ControleRecuperarRedeAmigo(string text, string text1, string text2)
        {
            return ModeloPersistencia.RecuperarTodosAmigos();
        }

        public RedeAmigo? ControleRecuperarIdeiaInovaPeloID(int id)
        {
            if (id > 0)
            {
                return ModeloPersistencia.RecuperarAmigoPeloID(id);
            }
            return null;
        }
    }
}

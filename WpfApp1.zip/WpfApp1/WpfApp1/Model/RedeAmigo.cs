﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfApp1.Persistencia;

namespace WpfApp1.Model
{
    internal class RedeAmigo
    {
        public int IdRedeAmigo { get; set; } = 0;

        public Boolean CadastrarRedeAmigo(RedeAmigo i)
        {
            BD.SalvarDB(i);

            return true;
        }

        public List<RedeAmigo> RecuperarTodosAmigos()
        {
            return BD.RetornarBD();
        }

        public RedeAmigo? RecuperarAmigoPeloID(int id)
        {
            return BD.RetornarBD(id);
        }

    }

}

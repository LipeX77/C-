﻿using System.ComponentModel;
using System.Diagnostics;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApp1.Control;
using WpfApp1.Model;
using WpfApp1.Persistencia;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private RedeAmigoControle objClasseII = new();

        private BindingList<RedeAmigo> objDataGridII = new();
        public MainWindow()
        {
            InitializeComponent();

            DataGridRedeAmigo.ItemsSource = objDataGridII;
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            List<RedeAmigo>? DadosRecuperados = null;

            DataGridRedeAmigo.ItemsSource = null;

            DadosRecuperados = objClasseII.ControleRe();

            //objClasseII.ControleRecuperarIdeiaInovaPeloID(int.Parse(TextBoxID.Text));

            objDataGridII = new(DadosRecuperados);

            DataGridRedeAmigo.ItemsSource = objDataGridII;

            private void Button_Click(object sender, RoutedEventArgs e)
        {

            if (!string.IsNullOrEmpty(TextBoxArea.Text) &&
                !string.IsNullOrEmpty(TextBoxDescricao.Text))
            {
                if (objClasseII.(
                                                        TextBoxAp.Text,
                                                        TextBoxTel.Text,
                                                        TextBoxEm.Text))

                    MessageBox.Show("Cadastro realizado com sucesso");
            }
            else
            {
                MessageBox.Show("Campos devem ser preenchido!!!");
            }

            Debug.WriteLine("===========================");
            BD.RetornarBD().ForEach(x => Debug.WriteLine(x));
            Debug.WriteLine("===========================");

        }
    }
    }
}